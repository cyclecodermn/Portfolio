﻿namespace GuildBikes.Models
{
    public class Queries
    {
    }
}