﻿namespace GuildCars2.Models
{
    public class Queries
    {
    }
}